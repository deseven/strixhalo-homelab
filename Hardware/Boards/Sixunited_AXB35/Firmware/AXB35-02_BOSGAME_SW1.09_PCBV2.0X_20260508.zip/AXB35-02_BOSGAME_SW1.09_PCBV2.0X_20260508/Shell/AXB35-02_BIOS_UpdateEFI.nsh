AfuEfix64.efi ../ROM/AXB3502109.bin /p /b /n /r /k /l /x /capsule /q
